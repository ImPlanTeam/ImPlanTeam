package What2Do;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class What2DoApplication {

	public static void main(String[] args) {
		SpringApplication.run(What2DoApplication.class, args);
	}

}

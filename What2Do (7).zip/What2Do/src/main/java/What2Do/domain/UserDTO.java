package What2Do.domain;

import jakarta.persistence.Id;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.Transient;

import java.time.LocalDateTime;


@Data
@Getter
@Setter
@NoArgsConstructor
public class UserDTO { //클라이언트가 회원가입 폼에 입력한 데이터를 담는다.

    @NotBlank(message = "아이디를 입력하세요.")
    private String id;

    @NotBlank(message = "비밀번호를 입력하세요.")
    @Size(min = 4, max = 15, message = "비밀번호는 4 ~ 15자 사이로 입력해주세요")
    private String pass;

    @Transient
    @NotBlank(message = "비밀번호를 확인하세요.")
    private String pass2;

    @AssertTrue(message = "비밀번호가 일치하지 않습니다.")
    public boolean PasswordMatching() {
        return pass != null && pass.equals(pass2);
    }

    @NotBlank(message = "닉네임을 입력하세요")
    private String name;

    @Email(message = "올바른 이메일 주소를 입력해주세요.")
    private String mail;

    private String mail1;
    private String mail2;

    private String tel;

    private String jender;

    private String birth;

    private LocalDateTime indate;

    public LocalDateTime getIndate() {
        return indate;
    }

    public void setIndate(LocalDateTime indate) {
        this.indate = indate;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getPass2() {
        return pass2;
    }

    public void setPass2(String pass2) {
        this.pass2 = pass2;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getJender() {
        return jender;
    }

    public void setJender(String jender) {
        this.jender = jender;
    }

    public String getBirth() {
        return birth;
    }

    public void setBirth(String birth) {
        this.birth = birth;
    }

    public String getMail1() {
        return mail1;
    }

    public void setMail1(String mail1) {
        this.mail1 = mail1;
    }

    public String getMail2() {
        return mail2;
    }

    public void setMail2(String mail2) {
        this.mail2 = mail2;
    }

    public User toEntity() {
        User user = new User();
        user.setName(this.name);
        user.setPass(this.pass); // 비밀번호는 보통 암호화 필요
        user.setMail(this.mail1+"@"+this.mail2);
        user.setId(this.id);
        user.setBirth(this.birth);
        user.setJender(this.jender);
        user.setTel(this.tel);
        return user;
    }

}

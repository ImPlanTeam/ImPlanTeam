package ImPlan.What2Do;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class What2DoApplicationTests {

	@Test
	void contextLoads() {
	}

}
